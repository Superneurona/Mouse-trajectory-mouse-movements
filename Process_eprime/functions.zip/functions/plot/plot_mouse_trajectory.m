function plot_mouse_trajectory(mouseTraj, straighTraj, data)

figure;

hold on
axis equal
grid on

title(sprintf('Mouse Trajectory for Subject %i and TrialNr %i',data.Subject,data.TrialNr));

plot(mouseTraj(:,1),mouseTraj(:,2));
plot(straighTraj(:,1),straighTraj(:,2),'--o');
set(gca,'YDir','reverse');

if isfield(data,'mad') && isfield(data,'auc')
    annotation('textbox','String',{sprintf('MAD: %g',data.mad),sprintf('AUC: %d',data.auc)},'FitBoxToText','on');
end

end