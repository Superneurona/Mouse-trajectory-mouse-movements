function select_plot_trial_trajectory(data, subjectNr, trialNr)

currentData = data(data.Subject == subjectNr & data.TrialNr == trialNr,:);
currentData = table2struct(currentData);

plot_mouse_trajectory(currentData.mouseTraj, currentData.straightTraj, currentData);

end