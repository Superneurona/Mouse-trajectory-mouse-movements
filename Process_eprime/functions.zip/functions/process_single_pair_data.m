function results = process_single_pair_data(tableFilepath, mdataFilepath)

arguments
    tableFilepath {mustBeFile}
    mdataFilepath {mustBeFile}
end

%% Import raw E-Prime data
eprimeTable = importfile_eprime_table(tableFilepath);
eprimeMdata = importfile_eprime_mdata(mdataFilepath);

%% Process data
assert(max(eprimeTable.TrialNr)==max(eprimeMdata.Trial), 'Number of trials must match.');

% Initialize results
results = [];

% Switch off warning for repaired polyshape out of mouse trajetory
warning('off','MATLAB:polyshape:repairedBySimplify');

fprintf('Processing data from set of imported files...\n');

% Loop over subject
for s = unique(eprimeTable.Subject)
    % Extract Table data for current subject
    tableData = eprimeTable(eprimeTable.Subject==s,:);
    
    % Loop over trials
    for t = tableData.TrialNr'
        % Add some initial data
        results(end+1).Subject = s;
        results(end).TrialNr = t;
        
        % Extract MData for current trial
        mdata = eprimeMdata(eprimeMdata.Trial == t,:);
        
        % Extract initial trajectory coordinates of interest
        rttraj = [tableData.RTx(tableData.TrialNr==t),...
            tableData.RTy(tableData.TrialNr==t)];
        
        % Search closest sample in MData to start analysis
        [~, startIdx] = min(sum(([mdata.X, mdata.Y] - rttraj).^2,2));
%         startIdx = 1;
        
        % Extract trajectory points from timespan of interest
        results(end).mouseTraj = [mdata.X(startIdx:end), mdata.Y(startIdx:end)];
                
        % Calculate straight line between initial and end points
        results(end).straightTraj = [results(end).mouseTraj(1,:); results(end).mouseTraj(end,:)];
                
        % Calculate maximum absolute distance over trajectory in pixels
        results(end).mad = sum(sqrt(sum(diff(results(end).mouseTraj).^2,2)));
        
        % Calculate polygon limited for mouse trajectory
        polyObj = polyshape(results(end).mouseTraj);
%         polyObj.plot;

        % Calculate area of the polygon as AUC
        results(end).auc = polyObj.area;
        assert(results(end).auc>=0);
        
    end
    
end

%% Postprocessing

% Convert results to table
results = struct2table(results);

fprintf('Import and processing of set of files successful.\n');

end