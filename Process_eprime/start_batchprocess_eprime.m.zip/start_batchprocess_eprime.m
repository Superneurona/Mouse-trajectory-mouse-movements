function results = start_batchprocess_eprime(inputEprimeDir)

arguments
    inputEprimeDir {mustBeFolder} = uigetdir(pwd,'Select root folder containing E-Prime data');
end

% Find all data files in and under root directory
alltxtFiles = dir(fullfile(inputEprimeDir,'**/*.txt'));
alldatFiles = dir(fullfile(inputEprimeDir,'**/*.dat'));

assert(length(alltxtFiles),length(alldatFiles),'The number of txt and dat files must be the same.');

% Process all data in a loop of pairs
results = [];
for i = 1:length(alltxtFiles)
    
    % Create search token for current txt file
    tokenTxtfile = strrep(alltxtFiles(i).name,'.txt','');
    tokenTxtfile = strrep(tokenTxtfile,'Table','');
    
    % Find corresponding dat file
    idxMatchDat = find(contains({alldatFiles.name}, tokenTxtfile), 1);
    assert(~isempty(idxMatchDat),'No corresponding dat file was found for %s.', alltxtFiles(i).name);
    
    % Process E-Prime data for current pair of files
    results = [results; process_single_pair_data(fullfile(alltxtFiles(i).folder,alltxtFiles(i).name),...
        fullfile(alldatFiles(idxMatchDat).folder,alldatFiles(idxMatchDat).name))];
end

end

